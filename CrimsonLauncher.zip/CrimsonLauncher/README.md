# Crimson Launcher

Red and black Android launcher for Minecraft Java + Bedrock.

- **Bedrock**: starts the official Minecraft app (`com.mojang.minecraftpe`).
- **Java**: starts PojavLauncher or Zalith Launcher if installed.
- If an edition is not installed, the button opens its download page.

## Build with GitHub

1. Create a new GitHub repo and upload all files from this folder.
2. Go to the **Actions** tab, open **Build APK**, and click **Run workflow**.
3. When it finishes, download `CrimsonLauncher-debug` from the run's Artifacts.
4. Unzip it and install the `.apk` on your phone.

## Build locally

Requires JDK 17 and Gradle 8.9+.

    gradle assembleDebug

APK output: `app/build/outputs/apk/debug/`

## Change colors

All colors live in `app/src/main/java/com/crimson/launcher/ui/Theme.kt`.
