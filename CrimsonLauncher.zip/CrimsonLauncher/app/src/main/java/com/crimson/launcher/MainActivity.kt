package com.crimson.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.crimson.launcher.ui.Crimson
import com.crimson.launcher.ui.CrimsonTheme

class MainActivity : ComponentActivity() {

    // Bumped on every resume so install status refreshes after coming back from the Play Store.
    private val refreshTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            CrimsonTheme {
                LauncherScreen(tick = refreshTick.intValue)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshTick.intValue++
    }
}

@Composable
fun LauncherScreen(tick: Int) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Crimson.BackgroundGradient)
    ) {
        Column(
            modifier = Modifier
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Header()
            EditionCard(edition = Games.java, tick = tick)
            EditionCard(edition = Games.bedrock, tick = tick)
            Text(
                text = "Java needs PojavLauncher or Zalith installed. " +
                    "Bedrock needs the official Minecraft app. " +
                    "You must own the game on your own account.",
                color = Crimson.TextMuted,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
private fun Header() {
    Column(modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)) {
        Text(
            text = "CRIMSON",
            color = Crimson.Red,
            fontSize = 40.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 6.sp,
        )
        Text(
            text = "LAUNCHER",
            color = Crimson.TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 10.sp,
        )
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .height(3.dp)
                .fillMaxWidth(0.35f)
                .clip(RoundedCornerShape(2.dp))
                .background(Crimson.RedGradient)
        )
    }
}

@Composable
private fun EditionCard(edition: Edition, tick: Int) {
    val context = LocalContext.current
    val installedPkg = remember(tick) { Games.installedPackage(context, edition) }
    val installed = installedPkg != null

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Crimson.Surface),
        border = BorderStroke(
            1.dp,
            if (installed) Crimson.Red else Crimson.SurfaceHigh
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (installed) Crimson.Green else Crimson.TextMuted)
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = if (installed) "READY" else "NOT INSTALLED",
                    color = if (installed) Crimson.Green else Crimson.TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                )
            }

            Text(
                text = edition.name,
                color = Crimson.TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp,
            )
            Text(
                text = edition.tagline,
                color = Crimson.TextMuted,
                fontSize = 13.sp,
            )

            Spacer(Modifier.height(4.dp))

            if (installed) {
                Button(
                    onClick = { Games.launchOrGet(context, edition) },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Crimson.Red,
                        contentColor = Color.White,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) {
                    Text("PLAY", fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                }
            } else {
                OutlinedButton(
                    onClick = { Games.launchOrGet(context, edition) },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.5.dp, Crimson.Red),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) {
                    Text(
                        edition.getLabel,
                        color = Crimson.Red,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                    )
                }
            }
        }
    }
}
