package com.crimson.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** One Minecraft edition the launcher can start. */
data class Edition(
    val name: String,
    val tagline: String,
    /** Package names that can start this edition, in priority order. */
    val packages: List<String>,
    /** Where to send the user when nothing is installed. */
    val getUrl: String,
    val getLabel: String,
)

object Games {

    val bedrock = Edition(
        name = "BEDROCK EDITION",
        tagline = "Official Minecraft app from Google Play",
        packages = listOf("com.mojang.minecraftpe"),
        getUrl = "https://play.google.com/store/apps/details?id=com.mojang.minecraftpe",
        getLabel = "GET ON PLAY STORE",
    )

    val java = Edition(
        name = "JAVA EDITION",
        tagline = "Runs through PojavLauncher / Zalith",
        packages = listOf(
            "net.kdt.pojavlaunch",
            "net.kdt.pojavlaunch.debug",
            "com.movtery.zalithlauncher",
        ),
        getUrl = "https://github.com/PojavLauncherTeam/PojavLauncher/releases",
        getLabel = "GET JAVA RUNTIME",
    )

    /** First installed package of this edition, or null. */
    fun installedPackage(context: Context, edition: Edition): String? =
        edition.packages.firstOrNull {
            context.packageManager.getLaunchIntentForPackage(it) != null
        }

    /** Starts the game if installed, otherwise opens the download page. */
    fun launchOrGet(context: Context, edition: Edition) {
        val pkg = installedPackage(context, edition)
        val intent = if (pkg != null) {
            context.packageManager.getLaunchIntentForPackage(pkg)
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse(edition.getUrl))
        }
        try {
            intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open ${edition.name}", Toast.LENGTH_SHORT).show()
        }
    }
}
