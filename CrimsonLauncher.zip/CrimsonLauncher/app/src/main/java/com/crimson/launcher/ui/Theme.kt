package com.crimson.launcher.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Crimson {
    val Black = Color(0xFF080808)
    val Surface = Color(0xFF141012)
    val SurfaceHigh = Color(0xFF1E1518)
    val Red = Color(0xFFE5202E)
    val RedDark = Color(0xFF8E0F1A)
    val RedGlow = Color(0xFFFF4D5A)
    val TextPrimary = Color(0xFFF5F0F0)
    val TextMuted = Color(0xFF9C8F91)
    val Green = Color(0xFF3DDC84)

    val RedGradient = Brush.horizontalGradient(listOf(RedDark, Red, RedGlow))
    val BackgroundGradient = Brush.verticalGradient(
        listOf(Color(0xFF1A0508), Black, Black)
    )
}

private val Scheme = darkColorScheme(
    primary = Crimson.Red,
    onPrimary = Color.White,
    background = Crimson.Black,
    onBackground = Crimson.TextPrimary,
    surface = Crimson.Surface,
    onSurface = Crimson.TextPrimary,
)

@Composable
fun CrimsonTheme(content: @Composable () -> Unit) {
    // Always dark: the launcher is red and black by design.
    MaterialTheme(colorScheme = Scheme, content = content)
}
